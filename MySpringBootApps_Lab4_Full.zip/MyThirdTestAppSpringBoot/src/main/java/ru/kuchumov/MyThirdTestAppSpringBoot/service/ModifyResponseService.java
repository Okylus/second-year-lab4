package ru.kuchumov.MyThirdTestAppSpringBoot.service;

import org.springframework.stereotype.Service;
import ru.kuchumov.MyThirdTestAppSpringBoot.model.Response;

@Service
public interface ModifyResponseService {
    Response modify(Response response);
}
