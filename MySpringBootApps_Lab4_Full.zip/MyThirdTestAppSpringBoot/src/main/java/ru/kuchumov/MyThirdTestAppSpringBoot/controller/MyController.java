package ru.kuchumov.MyThirdTestAppSpringBoot.controller;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.kuchumov.MyThirdTestAppSpringBoot.exception.ValidationFailedException;
import ru.kuchumov.MyThirdTestAppSpringBoot.model.*;
import ru.kuchumov.MyThirdTestAppSpringBoot.service.ModifyResponseService;
import ru.kuchumov.MyThirdTestAppSpringBoot.service.ValidationService;
import ru.kuchumov.MyThirdTestAppSpringBoot.util.DateTimeUtil;
import java.util.Date;

@Slf4j
@RestController
public class MyController {

    private final ValidationService validationService;
    private final ModifyResponseService modifyResponseService;

    @Autowired
    public MyController(
            ValidationService validationService,
            @Qualifier("ModifySystemTimeResponseService") ModifyResponseService modifyResponseService) {
        this.validationService = validationService;
        this.modifyResponseService = modifyResponseService;
    }

    @PostMapping(value = "/feedback")
    public ResponseEntity<Response> feedback(@Valid @RequestBody Request request,
                                             BindingResult bindingResult) {
        Date receivedAtService2 = new Date();
        log.info("request: {}", request);

        // Расчет разницы времени между получением Request в Сервисе 1 и в Сервисе 2
        try {
            if (request.getSystemTime() != null && !request.getSystemTime().isEmpty()) {
                Date sentFromService1 = DateTimeUtil.getCustomFormat().parse(request.getSystemTime());
                long diffMs = receivedAtService2.getTime() - sentFromService1.getTime();
                log.info("Время доставки модифицированного Request от Сервиса 1 до Сервиса 2: {} мс", diffMs);
            }
        } catch (Exception e) {
            log.error("Ошибка при вычислении разницы времени: {}", e.getMessage());
        }

        Response response = Response.builder()
                .uid(request.getUid())
                .operationUid(request.getOperationUid())
                .systemTime(DateTimeUtil.getCustomFormat().format(receivedAtService2))
                .code(Codes.SUCCESS)
                .errorCode(ErrorCodes.EMPTY)
                .errorMessage(ErrorMessages.EMPTY)
                .build();
        try {
            validationService.isValid(bindingResult);
        } catch (ValidationFailedException e) {
            response.setCode(Codes.FAILED);
            response.setErrorCode(ErrorCodes.VALIDATION_EXCEPTION);
            response.setErrorMessage(ErrorMessages.VALIDATION);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            response.setCode(Codes.FAILED);
            response.setErrorCode(ErrorCodes.UNKNOWN_EXCEPTION);
            response.setErrorMessage(ErrorMessages.UNKNOWN);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        modifyResponseService.modify(response);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
