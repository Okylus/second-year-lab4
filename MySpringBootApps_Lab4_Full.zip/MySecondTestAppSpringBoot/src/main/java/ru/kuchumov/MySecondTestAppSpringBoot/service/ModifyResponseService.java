package ru.kuchumov.MySecondTestAppSpringBoot.service;

import org.springframework.stereotype.Service;
import ru.kuchumov.MySecondTestAppSpringBoot.model.Response;

@Service
public interface ModifyResponseService {
    Response modify(Response response);
}
