package ru.kuchumov.MySecondTestAppSpringBoot.service;

import org.springframework.stereotype.Service;
import ru.kuchumov.MySecondTestAppSpringBoot.model.Request;

@Service
public interface ModifyRequestService {
    void modify(Request request);
}
